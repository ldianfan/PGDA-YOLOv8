import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO(r'yolov8.yaml')
    model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='E:/temp_detection/v8改三个点/Detection/data.yaml',
                cache=False,
                project='runs/train',
                name='exp',
                epochs=300,
                batch=8,
                plots=True,
                save=True
                )
